$(document).ready(function () {
    $('#dropdown-menu').click(() => {
        document.getElementById("dropdown-content").classList.toggle("show");
    });
});